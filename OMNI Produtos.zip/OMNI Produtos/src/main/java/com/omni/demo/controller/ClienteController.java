package com.omni.demo.controller;

import com.omni.demo.model.Cliente;
import com.omni.demo.service.ClienteService;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ClienteController {
    
    /* Injeção de depência via anotação */
    /* No instante que uma instância da classe CampoController é criada, uma instância da clsse CampoServiceImpl é injetada */
    /* elimina a necessidade de getters e setters nas classes que serão injetadas */
    /* não é a interface que é instanciada, mas a sua implementação */
    /* a interface esconde a implementação e só pode ter uma classe que a implemente. Caso contrário, ocorrerá um erro */
    @Autowired
    private ClienteService clienteService;
    
    @GetMapping("/clientes")
    public ResponseEntity<List<Cliente>> listaClientes(){
        return ResponseEntity.status(HttpStatus.OK).body(clienteService.listaClientes());
    }
    
    /* @PathVariable vincula o parâmetro passado pelo método com a variável do path */
    @GetMapping("cliente/{codcliente}")
    public ResponseEntity<Optional<Cliente>> getByIdCliente(@PathVariable Integer codcliente){
        return ResponseEntity.status(HttpStatus.OK).body(clienteService.getByIdCliente(codcliente));
    }

    @PostMapping("cliente")
    public ResponseEntity<Cliente> salvaCliente(@RequestBody Cliente cliente){
        return ResponseEntity.status(HttpStatus.CREATED).body(clienteService.salvaCliente(cliente));
    }

    @PutMapping("cliente")
    public ResponseEntity<Cliente> atualizaCliente(@RequestBody Cliente cliente){
        return ResponseEntity.status(HttpStatus.OK).body(clienteService.atualizaCliente(cliente));
    }
    
    /* @PathVariable vincula o parâmetro passado pelo método com a variável do path */
    @DeleteMapping("cliente/{codcliente}")
    public ResponseEntity<String> deleteByIdCliente(@PathVariable Integer codcliente){
        clienteService.deleteByIdCliente(codcliente);
        return ResponseEntity.status(HttpStatus.OK).body("Cliente removido com sucesso");
    }    
}
