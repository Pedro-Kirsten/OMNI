package model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "produto")
public class Produto implements Serializable {
    
    @Id
    @Column (name = "codigo")
    private int codigo;
    
    @Column (name = "nomeProduto")
    private String nomeproduto;
        
    @Column (name = "marca")
    private String marca;
    
    @Column (name = "valor")
    private double valor;
    
    @Column (name = "dataInsercao")
    private String datainsercao;

    public Produto(int codigo, String nomeproduto, String marca, double valor, String datainsercao) {
        this.codigo = codigo;
        this.nomeproduto = nomeproduto;
        this.marca = marca;
        this.valor = valor;
        this.datainsercao = datainsercao;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNomeproduto() {
        return nomeproduto;
    }

    public String getMarca() {
        return marca;
    }

    public double getValor() {
        return valor;
    }

    public String getDatainsercao() {
        return datainsercao;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setNomeproduto(String nomeproduto) {
        this.nomeproduto = nomeproduto;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public void setDatainsercao(String datainsercao) {
        this.datainsercao = datainsercao;
    }
    
    @Override
    public String toString() {
        return "Produto{" + "codProduto=" + codigo + ", nome do produto=" + nomeproduto + ", valor=" + valor + '}';
    }
    
}
