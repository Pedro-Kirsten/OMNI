package model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pessoa")
public class Pessoa implements Serializable {

    @Id
    @Column(name = "idPessoa")
    private int IdPessoa;

    @Column(name = "nomePessoa")
    private String nomePessoa;

    @Column(name = "datanascimento")
    private String datanascimento;
    
    @Column(name = "endereco")
    private String endereco;
    
    @Column(name = "telefone")
    private String telefone;

    public Pessoa(int IdPessoa, String nomePessoa, String datanascimento , String endereco, String telefone) {
        this.IdPessoa = IdPessoa;
        this.nomePessoa = nomePessoa;
        this.datanascimento = datanascimento;
        this.endereco = endereco;
        this.telefone = telefone;
    }
    
    public Pessoa() {
    }

    public int getIdPessoa() {
        return IdPessoa;
    }

    public String getNomePessoa() {
        return nomePessoa;
    }

    public String getDatanascimento() {
        return datanascimento;
    }
    
    public String getEndereco() {
        return endereco;
    }
    
    public String getTelefone() {
        return telefone;
    }
    
    public void setIdPessoa(int IdPessoa) {
        this.IdPessoa = IdPessoa;
    }

    public void setNomePessoa(String nomePessoa) {
        this.nomePessoa = nomePessoa;
    }
 
    public void setDatanascimento(String datanascimento) {
        this.datanascimento = datanascimento;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

}