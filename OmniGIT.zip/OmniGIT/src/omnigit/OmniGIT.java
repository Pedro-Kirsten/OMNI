package omnigit;

import view.CadastroLoja;
import view.LojaLista;

public class OmniGIT {

    public static void main(String[] args) {
        LojaLista Abrir = new LojaLista();
        Abrir.setVisible(true);
    }
    
}
